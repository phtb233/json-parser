module JSONParser (
    parseJSONtoXML,
    parseJSON,
    numberOfElements,
    avgPass,
    getMostPass,
    getLeastPass,
    getByState,
    getByYear,
    getByCode
    ) where


    import JSON
    import Data.Char(toLower)

    type Year       = Int
    type Count      = Int
    type State      = String
    type StateCode  = String
    type Row        = (Year, Count, State, StateCode)

    -- specific data type to hold the input.
    data PassportData =    PData [Row]
        deriving(Show, Eq)

    -- Takes a filepath, reads the JSON in its file, and outputs 
    -- it in GHCi using putStrLn.
    parseJSONtoXML :: FilePath -> IO ()
    parseJSONtoXML s  =
        do
            -- Take the file path and read the contents to jsonString.
            -- Remove '\r' characters for POSIX systems.
            jsonString <- readFile s
            putStrLn $ toXML $ toJSON $ unwords $ map (filter noTabOrReturn) $ lines jsonString
                where
                    noTabOrReturn c = c /= '\t' && c /= '\r'

    -- Takes a filepath and returns the contents within an IO JValue.
    parseJSON :: FilePath -> IO JValue
    parseJSON s =
        do
            jsonString <- readFile s
            return (toJSON $ unwords $ lines jsonString)


    {- 
        For the data set with the filename "statePassportIssuanceByFiscalYear.json"
        Taken from http://www.data.gov/
        Contains data about the number of passports issued in each state
        from 2007 to 2012
    -}

    -- These functions all use the PassportData, the datatype we've defined to hold
    -- the information from the JSON dataset.

    -- Get the number of elements in this set.
    numberOfElements :: IO (Int)
    numberOfElements =
        do
            j <- parseJSON "statePassportIssuanceByFiscalYear.json"
            let array = getArray j
            return $ length array


    -- Get all the rows in this set.
    getAll :: IO PassportData
    getAll  = 
        do
        j <- parseJSON "statePassportIssuanceByFiscalYear.json"
        return $ PData (getAll' (getArray j))
            where
            getAll' :: [JValue] -> [Row]
            getAll' [] = []
            getAll' (x : xs) = jObjectToPData x : getAll' xs


    -- Get record with the highest 'count' field.
    getMostPass :: IO PassportData
    getMostPass = 
        do
        j <- _getMostPass
        return $ PData (getMostPass' j)
        where
            getMostPass' :: JValue -> [Row]
            getMostPass' x = [jObjectToPData x]

    -- Get the tuple with the least passports issued in that year.
    getLeastPass :: IO PassportData
    getLeastPass =
        do
        j <- _getLeastPass
        return $ PData (getLeastPass' j)
        where
            getLeastPass' :: JValue -> [Row]
            getLeastPass' x = [jObjectToPData x]


    -- Filter results by state.
    getByState :: String -> IO PassportData
    getByState s =
        do
            j <- _getByState s
            return $ PData (getByState'(getArray j))
                where
                getByState' :: [JValue] -> [Row]
                getByState' [] = []
                getByState' (x:xs) = jObjectToPData x : getByState' xs



    -- Get all the tuples for a certain year.
    getByYear :: Int -> IO PassportData
    getByYear n =
        do
            j <- _getByYear n
            return $ PData (getByYear' (getArray j))
                where
                getByYear' :: [JValue] -> [Row]
                getByYear' [] = []
                getByYear' (x:xs) = jObjectToPData x : getByYear' xs


    -- Get a list of passports by the specified state code.        
    getByCode :: String -> IO PassportData
    getByCode s =
        do 
            j <- _getByCode s
            return $ PData (getByCode' $ getArray j)
                where
                getByCode' :: [JValue] -> [Row]
                getByCode' [] = []
                getByCode' (x : xs) = jObjectToPData x : getByCode' xs

    -- Find the average number of passports issued between the years 2007 and 2012.
    avgPass :: IO ()
    avgPass =
        do
            j <- parseJSON "statePassportIssuanceByFiscalYear.json"
            total <- numberOfElements
            putStrLn $ "The average number of passports issued from 2007 to 2012 is " ++ (show $ (averagePass j `div` total)) ++ "."
                where
                averagePass :: JValue -> Int
                averagePass (JArray (x : xs)) = 
                    let
                        (_, count') = head $ filter (isField "Count") $ getPairs x
                        count = getInt count'
                    in
                    count + (averagePass (JArray xs))
                averagePass _                 = 0


    -- Print passport data in XML format.
    pdataToXML :: PassportData -> String
    pdataToXML (PData []) = ""
    pdataToXML (PData xs) = 
        "<data>" ++ "\n"
        ++ concat (map (showPData' 4)  xs)
        ++ "</data>"
        where
        room i = replicate i ' '
        showPData' ind (y, c, s, sc) = 
            (room ind) ++ "<record>" ++ "\n" ++
            (room (ind + 4)) ++ "<year>" ++ (show y) ++ "</year>" ++ "\n" ++
            (room (ind + 4)) ++ "<count>" ++ (show c) ++ "</count>" ++ "\n" ++
            (room (ind + 4)) ++ "<state>" ++ s ++ "</state>" ++ "\n" ++
            (room (ind + 4)) ++ "<stateCode>" ++ sc ++ "</stateCode>" ++ "\n" ++
            (room ind) ++ "</record>" ++ "\n"


    {- 
        Internal functions that communicate with the data after it's been converted to the JSON data type 'JValue'.
        The passport functions take this underlying data and stores them as PassportData, which can then be output
        as XML using pdataToXML.
    -}

    _getMostPass :: IO JValue
    _getMostPass = 
        do
            j <- parseJSON "statePassportIssuanceByFiscalYear.json"
            return $ mostPass j
            where
                mostPass :: JValue -> JValue
                mostPass (JArray (y:ys)) = foldl check y ys
                    where
                        check a b
                            | count1 > count2  = a
                            | otherwise        = b
                            where
                                (_, count1) =  head $ filter (isField "Count") $ getPairs a
                                (_, count2) =  head $ filter (isField "Count") $ getPairs b

    
    _getLeastPass :: IO JValue
    _getLeastPass = 
        do
            j <- parseJSON "statePassportIssuanceByFiscalYear.json"
            return $ leastPass j
                where
                leastPass :: JValue -> JValue
                leastPass (JArray (x : xs)) = march x xs
                    where
                        march a []   = a
                        march a (b : bs)
                            |  count1 < count2 = march a bs
                            | otherwise        = march b bs
                                where
                                    (_, count1) =  head $ filter (isField "Count") $ getPairs a
                                    (_, count2) =  head $ filter (isField "Count") $ getPairs b
                                    



    _getByState :: String -> IO JValue
    _getByState s =
        do
            j <- parseJSON "statePassportIssuanceByFiscalYear.json"
            return $ byState s j
            where
                byState :: String -> JValue -> JValue
                byState s (JArray xs) = JArray (foldr check [] xs)
                    where 
                        check a b 
                            | state' == s'     = a : b
                            | otherwise        = b
                                where
                                   (_, state ) = head $ filter (isField "State") $ getPairs a
                                   s' = map toLower s
                                   state' = map toLower $ getString state


    
    _getByYear :: Int -> IO JValue
    _getByYear n = 
        do
            j <- parseJSON "statePassportIssuanceByFiscalYear.json"
            return $ byYear n j
            where
                byYear :: Int -> JValue -> JValue
                byYear n (JArray xs) = JArray (filter isMyYear xs)
                    where
                        isMyYear (JObject ys) = year' == n
                            where
                                (_, year) = head $ filter (isField "Year") ys
                                year' = getInt year
                                


    
    _getByCode :: String -> IO JValue
    _getByCode s = 
        do
            j <- parseJSON "statePassportIssuanceByFiscalYear.json"
            return $ byCode s j
            where
                byCode :: String -> JValue -> JValue
                byCode s (JArray xs) = JArray (filter isMyCode xs)
                    where
                        isMyCode (JObject ys) = code' == map toLower s
                            where
                                (_, code) = head $ filter (isField "StateCode") ys
                                code' = map toLower $ getString code
                                


    {- Helper functions -}

    -- Test that a particular field matches the given test.
    isField :: String -> (String, JValue) -> Bool
    isField test (name, _) = name == test

    -- Convert a JObject to a row of data.
    jObjectToPData :: JValue -> Row
    jObjectToPData (JObject xs) = (yr, count, state, stateCode)
        where
        yr         = getInt $ snd $ head $ filter (isField "Year")          xs
        count      = getInt $ snd $ head $ filter (isField "Count")         xs
        state      = getString $ snd $ head $ filter (isField "State")      xs
        stateCode  = getString $ snd $ head $ filter (isField "StateCode")  xs    

